const BtnStart = document.querySelector(".button");
const grid = document.getElementById("gamegrid");
var Start = false;
var board =[];
var btn = [];
var row =10;
var col = 10;
w = "78px"

BtnStart.addEventListener("click",AddGridBtn);

function AddGridBtn()
{
    board = CreateBoard(col,row);
    AddMines(10);
    if(Start == false)
    {
    console.log("Click")
    for(var i = 0; i< col; i++)
    {
        btn[i] = Cell("78px",i)
        for(var j = 0; j< row; j++)
        { 
            btn[i][j] = Cell("78px",i+"/"+j)
            grid.appendChild(btn[i][j]);
        }
    }
    
    Start = true;    
    }
}

function CreateBoard(c,r)
{ 
    var arr = [];
    for(var i = 0; i<c ; i++)
    {
        arr[i] = [];
        for(var j =0; j<r ; j++)
        {
            arr[i][j] = Math.random();   
        }

    }

    return arr;
    
}

function Cell(w,value)
{
    const newBtn = document.createElement("button");
    newBtn.style.width = w;
    newBtn.style.height = w;
    //newBtn.style.position ='absolute';
    newBtn.addEventListener("click",function RevealValue()
    {
        newBtn.textContent = value;
    });
    return newBtn;
}


function AddMines(bomb)
{
    

    while(bomb > 0)
    {
        var x = Math.floor(Math.random()*10);
        var y = Math.floor(Math.random()*10);
        
        if(board[x][y] == -1) continue;

        board[x][y] = -1;
        bomb--;
    }
}